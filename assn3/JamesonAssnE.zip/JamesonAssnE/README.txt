So this is just the BasicSearch.java with the queries i am adding.
Queries 1-6
Still working on them!

Happy Coding All